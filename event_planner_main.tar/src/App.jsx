
import './App.css'
import EventPlanner from './Components/EventPlanner'

function App() {
  return (
 <>
 <EventPlanner/>
 </>
  )
}

export default App
